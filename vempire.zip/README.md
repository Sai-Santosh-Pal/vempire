# Vempire

A RPG-style game made in Pygame.

## Steps to download
- Download .zip from [Releases]()
- Extract it
- 