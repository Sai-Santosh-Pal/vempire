# Vempire

A RPG-style game made in Pygame.

## Steps to download
- Download .zip from [Releases]()
- Extract it
- VERY IMPORTANT - `pip install pytmx pygame` - RUN THIS BEFORE RUNNING THE CODE
- Open in terminal and run `python code/main.py`

## How To Play & Instructions
- WASD - To Move
- Left Click - To Shoot
- Killing Enemies -> Get 3 Coins -> Use Them For Upgrades
- E - To Open Upgrade Market
- 1,2,3... - To Select Stat To Upgrade
- Game Over when attacked by the enemies